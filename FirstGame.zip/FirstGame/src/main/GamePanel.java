package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import entity.Player;
import object.SuperObject;
import tile.TileManager;

public class GamePanel extends JPanel implements Runnable{
	
	// SCREEN SETTINGS
	final int origionalTileSize = 16; // 16x 16 tile (default) e.g. character
	final int scale = 3; // scales for monitors res ((16 x 16) x3) 
	
	public final int tileSize = origionalTileSize * scale; // 48x48
	public final int maxScreenCol = 16;
	public final int maxScreenRow = 12; // width x height
	public final int screenWidth = tileSize * maxScreenCol; //48 * 16 = 768 Pixels 
	public final int screenHeight = tileSize * maxScreenRow; // 48 * 12  = 576 Pixels
	
	//WORLD SETTINGS
	public final int maxWorldCol = 50;
	public final int maxWorldRow = 50;

	
	//FPS 
	int FPS = 60;
	
	TileManager tileM = new TileManager(this);
	KeyHandler keyH = new KeyHandler();
	Sound sound = new Sound();
	public CollisionChecker cChecker = new CollisionChecker(this);
	public AssetSetter aSetter = new AssetSetter(this); 
	Thread gameThread; // keep game running
	
	//ENTITY AND OBJECT
	public Player player = new Player(this, keyH);
	public SuperObject obj[] = new SuperObject[10]; // 10 slots on screen at same time
	 
	
	public GamePanel () {
		
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		this.setBackground(Color.black);
		this.setDoubleBuffered(true); //improves rendering 
		this.addKeyListener(keyH);
		this.setFocusable(true); // gamePanel focused on key inputs
	}
	
	public void setupGame() {
		
		aSetter.setObject();
		
		playMusic(0);
		
	}
	public void startGameThread() {
		
		gameThread = new Thread(this); 
		gameThread.start(); // calls run method below automatically
		
	}
	@Override
	public void run() {
		
		double drawInterval = 1000000000/FPS; // updates every 0.016666 seconds
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;
		long timer = 0;
		int drawCount = 0;
		
		while(gameThread != null) { 
			
			currentTime = System.nanoTime();
			
			delta += (currentTime - lastTime) / drawInterval;
			timer +=(currentTime - lastTime);
			lastTime = currentTime;
			
			if(delta >= 1) {
				update();
				repaint();
				delta--;
				drawCount++;
			}
			
			if(timer >= 1000000000) {
				System.out.println("FPS: " + drawCount);
				drawCount =0;
				timer = 0;
			}
		}
		
		
	}
	public void update() {
		
		player.update(); // moved to player class
		
	}
	public void paintComponent(Graphics g) { //JPanel draw method built in
		
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g; //more function that graphics above
		
		//TILE
		tileM.draw(g2); // draw the tiles first before the players cuz player wont be seen if not.
		
		//OBJECT
		for(int i = 0; i < obj.length; i++) { // for object in array 1 by 1 
			
			if(obj[i] != null) { 
				obj[i].draw(g2, this); // without this, would get null pointer error
			}
		}
		
		//PLAYER
		player.draw(g2);
		
		g2.dispose(); //saves memory
		
	}
	
	public void playMusic(int i) {
		
		sound.setFile(i);
		sound.play();
		sound.loop();

	}
	public void stopMusic() {
		
		sound.stop();
	}
	public void playSE(int i) {  //sound effects
		
		sound.setFile(i);
		sound.play();
	}
}
